import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectMultiplecvComponent } from './select-multiplecv.component';

describe('SelectMultiplecvComponent', () => {
  let component: SelectMultiplecvComponent;
  let fixture: ComponentFixture<SelectMultiplecvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectMultiplecvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectMultiplecvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
