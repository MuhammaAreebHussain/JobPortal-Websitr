import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-multiplecv',
  templateUrl: './select-multiplecv.component.html',
  styleUrls: ['./select-multiplecv.component.css']
})
export class SelectMultiplecvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
