import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AppRouteGuard } from '@shared/auth/auth-route-guard';
import { HomeComponent } from './home/home.component';
import { IndexComponent } from './job_portal/index/index.component';
import { ContactComponent } from './job_portal/contact/contact.component';
import { BlogComponent } from './job_portal/blog/blog.component';
import { JobsComponent } from './job_portal/jobs/jobs.component';
import { CandidatesComponent } from './job_portal/candidates/candidates.component';
import { AboutComponent } from './about/about.component';
import { UsersComponent } from './users/users.component';
import { TenantsComponent } from './tenants/tenants.component';
import { RolesComponent } from 'app/roles/roles.component';
import { ChangePasswordComponent } from './users/change-password/change-password.component';
import { JobseekerComponent } from './job_portal/jobseeker/jobseeker.component';
import { EmployerComponent } from './job_portal/employer/employer.component';
import { RegistrationComponent } from './job_portal/registration/registration.component';
import { CvBuilderComponent } from './cv-builder/cv-builder.component';
import { CvDetailComponent } from './cv-detail/cv-detail.component';

import { CcccComponent } from './cccc/cccc.component';

import { BuildingCVComponent } from './job_portal/building-cv/building-cv.component';

import { DshboardComponent } from './job_portal/dshboard/dshboard.component';

import { Buildingcv2Component } from './job_portal/buildingcv2/buildingcv2.component';

import { Buildingcv3Component } from './job_portal/buildingcv3/buildingcv3.component';

import { AboutcvComponent } from './job_portal/aboutcv/aboutcv.component';

import { SavejobComponent } from './job_portal/savejob/savejob.component';

import { ApplyjobdetailComponent } from './job_portal/applyjobdetail/applyjobdetail.component';

import { ApplyjoblistComponent } from './job_portal/applyjoblist/applyjoblist.component';

import { ThankyouComponent } from './job_portal/thankyou/thankyou.component';

import { EditcvComponent } from './job_portal/editcv/editcv.component';

import { Editcv2Component } from './job_portal/editcv2/editcv2.component';

import { Editcv3Component } from './job_portal/editcv3/editcv3.component';



@NgModule({
    imports: [
        
        RouterModule.forChild([
            {
                path: 'admin',
                component: AppComponent,
                children: [
                    { path: 'home', component: HomeComponent },
                    { path: 'users', component: UsersComponent, data: { permission: 'Pages.Users' }, canActivate: [AppRouteGuard] },
                    { path: 'roles', component: RolesComponent, data: { permission: 'Pages.Roles' }, canActivate: [AppRouteGuard] },
                    { path: 'tenants', component: TenantsComponent, data: { permission: 'Pages.Tenants' }, canActivate: [AppRouteGuard] },
                    { path: 'about', component: AboutComponent },
                    { path: 'update-password', component: ChangePasswordComponent }
                ]
            },
            { path: 'index', component: IndexComponent},
            { path: 'contact', component: ContactComponent},
            { path: 'blog', component: BlogComponent},
            { path: 'jobs', component: JobsComponent},
            { path: 'candidates', component: CandidatesComponent},
            { path: 'jobseeker', component: JobseekerComponent},
            { path: 'employer', component: EmployerComponent},
            { path: 'registration', component: RegistrationComponent} ,
            { path: 'cvbuilder', component: CvBuilderComponent},
            { path: 'cvdetail', component: CvDetailComponent },
            { path: 'buildingcv', component: BuildingCVComponent },
            { path: 'dshboard', component: DshboardComponent },
            { path: 'buildingcv2', component: Buildingcv2Component },
            { path: 'buildingcv3', component: Buildingcv3Component },
            { path: 'aboutcv', component: AboutcvComponent },
            { path: 'savejob', component: SavejobComponent },
            { path: 'applyjobdetail', component: ApplyjobdetailComponent },
            { path: 'applyjoblist', component: ApplyjoblistComponent },
            { path: 'thankyou', component: ThankyouComponent },
            { path: 'editcv', component: EditcvComponent },
            { path: 'editcv2', component: Editcv2Component },
            { path: 'editcv3', component: Editcv3Component },
            { path: 'test', component: CcccComponent}       
        ])
    ],
    exports: [RouterModule]
})
export class AppRoutingModule { }
