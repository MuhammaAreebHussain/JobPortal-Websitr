import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-cccc',
  templateUrl: './cccc.component.html',
  styleUrls: ['./cccc.component.css']
})
export class CcccComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
