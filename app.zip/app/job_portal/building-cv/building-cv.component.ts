import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-building-cv',
  templateUrl: './building-cv.component.html',
  styleUrls: ['./building-cv.component.css']
})
export class BuildingCVComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
