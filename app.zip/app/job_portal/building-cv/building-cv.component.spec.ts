import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildingCVComponent } from './building-cv.component';

describe('BuildingCVComponent', () => {
  let component: BuildingCVComponent;
  let fixture: ComponentFixture<BuildingCVComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildingCVComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildingCVComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
