import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcv',
  templateUrl: './editcv.component.html',
  styleUrls: ['./editcv.component.css']
})
export class EditcvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
