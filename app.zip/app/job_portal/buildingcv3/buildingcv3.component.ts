import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buildingcv3',
  templateUrl: './buildingcv3.component.html',
  styleUrls: ['./buildingcv3.component.css']
})
export class Buildingcv3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
