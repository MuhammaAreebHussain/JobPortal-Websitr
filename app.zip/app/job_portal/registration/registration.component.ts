import { Component, OnInit, HostListener, Directive, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import { ConfirmEqualValidatorDirective } from './confirm-equal-validator.directive';


declare var NgForm: any;
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {
    registerForm: FormGroup;
    submitted = false;
    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            txtInputEmail: ['', [Validators.required, Validators.email]],
            txtInputConfirmEmail: ['', [Validators.required, Validators.email]],
            txtInputPassword: ['', [Validators.required, Validators.minLength(6)]],
            txtInputConfirmPassword: ['', [Validators.required, Validators.minLength(6)]],
            txtInputDate: ['', [Validators.required]],
            txtInputNationality: ['', [Validators.required]],
            txtInputLocation: ['', [Validators.required]],
            txtInputCity: ['', [Validators.required]],
            txtInputDegree: ['', [Validators.required]],
            txtInputMobile: ['', [Validators.required]],
            // txtInputAlternateMobile: ['', [Validators.required]],
            // txtInputLadLineNumber: ['', [Validators.required]],
            // txtInputFaxNumber: ['', [Validators.required]],

        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
    
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
         
        // alert('SUCCESS!! :-)')
        window.open('/thankyou', '_self');
      
    }
  
  @HostListener('document:scroll', [])
  onScroll(): void {
       console.log('I am scrolled');

       var scrollWindow = function() {

        $(window).scroll(function(){

          var $w = $(this),
              st = $w.scrollTop(),
              navbar = $('.ftco_navbar'),
              sd = $('.js-scroll-wrap');
    
          if (st > 150) {
            if ( !navbar.hasClass('scrolled') ) {
              console.log('I have scrolled');
              navbar.addClass('scrolled');	
            }
          } 
          if (st < 150) {
          
            if ( navbar.hasClass('scrolled') ) {
              console.log('I have scrolled');


              navbar.removeClass('scrolled sleep');
            }
          } 
          if ( st > 350 ) {
            if ( !navbar.hasClass('awake') ) {
              navbar.addClass('awake');	
            }
            
            if(sd.length > 0) {
              sd.addClass('sleep');
            }
          }
          if ( st < 350 ) {
            if ( navbar.hasClass('awake') ) {
              navbar.removeClass('awake');
              navbar.addClass('sleep');
            }
            if(sd.length > 0) {
              sd.removeClass('sleep');
            }
          }
        });
      };
      scrollWindow();
    }
    
}
