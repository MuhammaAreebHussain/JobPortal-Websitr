import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcv3',
  templateUrl: './editcv3.component.html',
  styleUrls: ['./editcv3.component.css']
})
export class Editcv3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
