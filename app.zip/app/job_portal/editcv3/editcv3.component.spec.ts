import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Editcv3Component } from './editcv3.component';

describe('Editcv3Component', () => {
  let component: Editcv3Component;
  let fixture: ComponentFixture<Editcv3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Editcv3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Editcv3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
