import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applyjobdetail',
  templateUrl: './applyjobdetail.component.html',
  styleUrls: ['./applyjobdetail.component.css']
})
export class ApplyjobdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
