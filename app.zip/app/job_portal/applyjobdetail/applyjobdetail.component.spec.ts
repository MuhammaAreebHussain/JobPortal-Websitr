import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyjobdetailComponent } from './applyjobdetail.component';

describe('ApplyjobdetailComponent', () => {
  let component: ApplyjobdetailComponent;
  let fixture: ComponentFixture<ApplyjobdetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplyjobdetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyjobdetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
