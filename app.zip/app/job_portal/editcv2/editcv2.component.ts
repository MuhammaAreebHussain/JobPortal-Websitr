import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcv2',
  templateUrl: './editcv2.component.html',
  styleUrls: ['./editcv2.component.css']
})
export class Editcv2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
