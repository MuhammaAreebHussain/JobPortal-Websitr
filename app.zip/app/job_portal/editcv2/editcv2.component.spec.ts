import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Editcv2Component } from './editcv2.component';

describe('Editcv2Component', () => {
  let component: Editcv2Component;
  let fixture: ComponentFixture<Editcv2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Editcv2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Editcv2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
