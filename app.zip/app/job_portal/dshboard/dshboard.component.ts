import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dshboard',
  templateUrl: './dshboard.component.html',
  styleUrls: ['./dshboard.component.css']
})
export class DshboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
