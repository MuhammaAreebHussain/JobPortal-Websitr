import { Component, OnInit,HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-jobseeker',
  templateUrl: './jobseeker.component.html',
  styleUrls: ['./jobseeker.component.css']
})
export class JobseekerComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  IsValid = false;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
        txtInputSignInEmail: ['', [Validators.required, Validators.email, this.checkValidEmail]],
        txtInputSignInPassword: ['', [Validators.required, this.checkValidPassword]],
    });
    }

    checkValidEmail(control: AbstractControl) {
        if (control.value == 'naveedslote') {
            this.IsValid = true;
                    this.checkValidPassword;
                }
                else {
                    return false;

                }
    }

    checkValidPassword(control: AbstractControl) {
        if (control.value == 'nash' && this.IsValid) {
            this.checkValidEmail;
        }
        else {
            return false;
        }
    }

// convenience getter for easy access to form fields
get f() { return this.loginForm.controls; }

onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        alert("Wrong Email ID or Password");
    }
    else {
        window.open('/dshboard', '_self');
    }
}
  @HostListener('document:scroll', [])
  onScroll(): void {
       console.log('I am scrolled');

       var scrollWindow = function() {

        $(window).scroll(function(){

          var $w = $(this),
              st = $w.scrollTop(),
              navbar = $('.ftco_navbar'),
              sd = $('.js-scroll-wrap');
    
          if (st > 150) {
            if ( !navbar.hasClass('scrolled') ) {
              console.log('I have scrolled');
              navbar.addClass('scrolled');	
            }
          } 
          if (st < 150) {
          
            if ( navbar.hasClass('scrolled') ) {
              console.log('I have scrolled');


              navbar.removeClass('scrolled sleep');
            }
          } 
          if ( st > 350 ) {
            if ( !navbar.hasClass('awake') ) {
              navbar.addClass('awake');	
            }
            
            if(sd.length > 0) {
              sd.addClass('sleep');
            }
          }
          if ( st < 350 ) {
            if ( navbar.hasClass('awake') ) {
              navbar.removeClass('awake');
              navbar.addClass('sleep');
            }
            if(sd.length > 0) {
              sd.removeClass('sleep');
            }
          }
        });
      };
      scrollWindow();
 }

}
