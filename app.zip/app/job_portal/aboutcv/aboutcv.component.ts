import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutcv',
  templateUrl: './aboutcv.component.html',
  styleUrls: ['./aboutcv.component.css']
})
export class AboutcvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
