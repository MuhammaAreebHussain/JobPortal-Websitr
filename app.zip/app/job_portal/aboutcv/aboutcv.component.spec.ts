import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutcvComponent } from './aboutcv.component';

describe('AboutcvComponent', () => {
  let component: AboutcvComponent;
  let fixture: ComponentFixture<AboutcvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutcvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutcvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
