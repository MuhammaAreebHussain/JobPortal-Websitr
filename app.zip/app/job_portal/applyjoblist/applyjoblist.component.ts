import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applyjoblist',
  templateUrl: './applyjoblist.component.html',
  styleUrls: ['./applyjoblist.component.css']
})
export class ApplyjoblistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
