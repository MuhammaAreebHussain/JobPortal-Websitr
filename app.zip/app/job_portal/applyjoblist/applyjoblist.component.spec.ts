import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyjoblistComponent } from './applyjoblist.component';

describe('ApplyjoblistComponent', () => {
  let component: ApplyjoblistComponent;
  let fixture: ComponentFixture<ApplyjoblistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplyjoblistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyjoblistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
