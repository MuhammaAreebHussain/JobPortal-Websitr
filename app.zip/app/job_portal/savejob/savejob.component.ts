import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-savejob',
  templateUrl: './savejob.component.html',
  styleUrls: ['./savejob.component.css']
})
export class SavejobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
