import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buildingcv2',
  templateUrl: './buildingcv2.component.html',
  styleUrls: ['./buildingcv2.component.css']
})
export class Buildingcv2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
