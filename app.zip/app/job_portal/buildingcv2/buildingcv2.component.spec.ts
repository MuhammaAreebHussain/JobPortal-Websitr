import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Buildingcv2Component } from './buildingcv2.component';

describe('Buildingcv2Component', () => {
  let component: Buildingcv2Component;
  let fixture: ComponentFixture<Buildingcv2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Buildingcv2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Buildingcv2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
